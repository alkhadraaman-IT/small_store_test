package com.example.small_stores_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
